# subir-archivos-ajax-php
 Subir varios archivos usando JavaScript, AJAX, FormData y PHP

# Tutorial
https://parzibyte.me/blog/2021/01/26/subir-varios-archivos-php-ajax/