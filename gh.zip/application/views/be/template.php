<?php $this->load->view('be/layout/header'); ?>
<?php $this->load->view('be/layout/sidebar'); ?>
<?=$contents?>
<?php $this->load->view('be/layout/footer'); ?>
 