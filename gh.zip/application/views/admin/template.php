<?php $this->load->view('admin/layout/header'); ?>
<?php $this->load->view('admin/layout/sidebar'); ?>
<?=$contents?>
<?php $this->load->view('admin/layout/footer'); ?>
 